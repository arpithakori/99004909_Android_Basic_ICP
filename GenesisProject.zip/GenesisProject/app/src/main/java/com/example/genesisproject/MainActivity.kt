package com.example.genesisproject

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val actionBar = supportActionBar
        actionBar!!.title = "Login and Register"
        login_btn.setOnClickListener{
            var myusername = username_et.text.toString()
            var mypassword = password_et.text.toString()
            var status = if (username_et.text.toString().equals("Arpitha")
                &&password_et.text.toString().equals("password"))"Login Successful" else "Login Failed"
            Toast.makeText(this, status,Toast.LENGTH_LONG).show()
            val intent = Intent(this, SecondActivity::class.java)
            intent.putExtra("un",myusername)
            intent.putExtra("un1",mypassword)


            if (status.equals("Login Successful"))
                startActivity(intent)


        }
        register_btn.setOnClickListener{
            val intent = Intent(this, ThirdAcctivity::class.java)
            startActivity(intent)
        }
    }
}